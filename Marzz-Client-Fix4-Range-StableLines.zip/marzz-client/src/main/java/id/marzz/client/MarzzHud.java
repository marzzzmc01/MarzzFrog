package id.marzz.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Lightweight client HUD: keystrokes, FPS and player coordinates. */
public final class MarzzHud {
    private static final int PURPLE = 0xFFB78CFF;
    private static final int PANEL = 0xA91A1428;
    private MarzzHud() {}

    public static void register() {
        HudRenderCallback.EVENT.register(MarzzHud::render);
    }

    private static void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) return;
        int x = 8;
        int y = 8;
        if (MarzzHudConfig.showFps) {
            String fps = "FPS " + client.getCurrentFps();
            panel(context, x, y, client.textRenderer.getWidth(fps) + 12, 18);
            context.drawTextWithShadow(client.textRenderer, Text.literal(fps), x + 6, y + 5, 0xFFFFFFFF);
            y += 22;
        }
        if (MarzzHudConfig.showCoordinates) {
            String coords = String.format(java.util.Locale.ROOT, "XYZ %.1f / %.1f / %.1f",
                    client.player.getX(), client.player.getY(), client.player.getZ());
            panel(context, x, y, client.textRenderer.getWidth(coords) + 12, 18);
            context.drawTextWithShadow(client.textRenderer, Text.literal(coords), x + 6, y + 5, PURPLE);
        }
        if (MarzzHudConfig.showKeystrokes) renderKeys(context, client);
    }

    private static void renderKeys(DrawContext context, MinecraftClient client) {
        int x = 8;
        int y = client.getWindow().getScaledHeight() - 76;
        int size = 20;
        key(context, client, x + size + 3, y, size, "W", GLFW.GLFW_KEY_W);
        key(context, client, x, y + size + 3, size, "A", GLFW.GLFW_KEY_A);
        key(context, client, x + size + 3, y + size + 3, size, "S", GLFW.GLFW_KEY_S);
        key(context, client, x + (size + 3) * 2, y + size + 3, size, "D", GLFW.GLFW_KEY_D);
        key(context, client, x, y + (size + 3) * 2, size * 2 + 3, "LMB", -1, GLFW.GLFW_MOUSE_BUTTON_1);
        key(context, client, x + (size + 3) * 2, y + (size + 3) * 2, size * 2 + 3, "RMB", -1, GLFW.GLFW_MOUSE_BUTTON_2);
    }

    private static void key(DrawContext context, MinecraftClient client, int x, int y, int size, String label, int key) {
        boolean down = key >= 0 && InputUtil.isKeyPressed(client.getWindow(), key);
        drawKey(context, x, y, size, size, label, down);
    }

    private static void key(DrawContext context, MinecraftClient client, int x, int y, int width, String label, int ignored, int mouseButton) {
        boolean down = GLFW.glfwGetMouseButton(client.getWindow().getHandle(), mouseButton) == GLFW.GLFW_PRESS;
        drawKey(context, x, y, width, 20, label, down);
    }

    private static void drawKey(DrawContext context, int x, int y, int width, int height, String label, boolean down) {
        context.fill(x, y, x + width, y + height, down ? 0xE66B42B8 : PANEL);
        context.drawStrokedRectangle(x, y, width, height, down ? 0xFFFFC7FF : PURPLE);
        context.drawCenteredTextWithShadow(MinecraftClient.getInstance().textRenderer, Text.literal(label),
                x + width / 2, y + 6, 0xFFFFFFFF);
    }

    private static void panel(DrawContext context, int x, int y, int width, int height) {
        context.fill(x, y, x + width, y + height, PANEL);
        context.fill(x, y, x + width, y + 1, PURPLE);
    }
}
