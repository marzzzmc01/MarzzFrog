package id.marzz.client;

/** Toggles for the Marzz on-screen HUD. */
public final class MarzzHudConfig {
    private MarzzHudConfig() {}
    public static boolean showKeystrokes = true;
    public static boolean showFps = true;
    public static boolean showCoordinates = true;
}
